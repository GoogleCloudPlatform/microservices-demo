#!/usr/bin/env bash
set -euo pipefail

missing_required=0

check_required() {
  local name="$1"
  if command -v "$name" >/dev/null 2>&1; then
    echo "OK: $name"
  else
    echo "MISSING: $name is not installed (required)"
    missing_required=1
  fi
}

check_optional() {
  local name="$1"
  local hint="$2"
  if command -v "$name" >/dev/null 2>&1; then
    echo "OK: $name"
  else
    echo "WARN: $name is not installed (optional — ${hint})"
  fi
}

check_required jq
check_required git
check_optional gh "needed for /preflight-pr to open pull requests"

if [[ "$missing_required" -ne 0 ]]; then
  echo ""
  echo "One or more required dependencies are missing. Install them and re-run /preflight." >&2
  exit 1
fi

exit 0
